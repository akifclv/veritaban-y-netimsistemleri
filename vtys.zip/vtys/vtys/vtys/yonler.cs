﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vtys
{
    public partial class yonler : Form
    {
        public yonler()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection(" server=localHost; port=5432; Database=postgress ; user ID=postgres ; password=1234");

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into kisigucluyonu(yetenek_id,gucluyonu_adi,gucluyon_seviyesi) values(@p1,@p2,@p3)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
            komut1.Parameters.AddWithValue("@p2", textBox2.Text);
            komut1.Parameters.AddWithValue("@p3", comboBox1.Text);
            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme basarili...");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("Update kisigucluyonu set gucluyonu_adi=@p2,gucluyon_seviyesi=@p3 where yetenek_id=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
            komut3.Parameters.AddWithValue("@p2", textBox2.Text);
            komut3.Parameters.AddWithValue("@p3", comboBox1.Text);
            komut3.ExecuteNonQuery();
            MessageBox.Show(" güncelleme basarili");
            baglanti.Close();

            string sorgu = "select * from kisigucluyongecmis";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut4 = new NpgsqlCommand("Delete from kisigucluyonu where yetenek_id=@p1", baglanti);
            komut4.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
            komut4.ExecuteNonQuery();
            MessageBox.Show(" Silme basarili..");
            baglanti.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from kisigucluyonu";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
