﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vtys
{   
    public partial class çalıştığı_isler : Form
    {
        NpgsqlConnection baglanti = new NpgsqlConnection(" server=localHost; port=5432; Database=postgress ; user ID=postgres ; password=1234");
        public çalıştığı_isler()
        {
            InitializeComponent();
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into calistigiis(is_id,is_adi,is_maas,kullanici_id) values(@p1,@p2,@p3,@p4)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
            komut1.Parameters.AddWithValue("@p2", textBox2.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(textBox3.Text));
            komut1.Parameters.AddWithValue("@p4", int.Parse(textBox4.Text));
  
            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show(" ekleme basarili");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("Update calistigiis set is_adi=@p2,is_maas=@p3,kullanici_id=@p4 where is_id=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
            komut3.Parameters.AddWithValue("@p2", textBox2.Text);
            komut3.Parameters.AddWithValue("@p3", int.Parse(textBox3.Text));
            komut3.Parameters.AddWithValue("@p4", int.Parse(textBox4.Text));

            komut3.ExecuteNonQuery();
            MessageBox.Show(" güncellem basarili");
            baglanti.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut2 = new NpgsqlCommand("Delete from calistigiis where is_id=@p1", baglanti);
            komut2.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
            komut2.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("silme basarili");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from calistigiis";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];


        }

        private void çalıştığı_isler_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut5 = new NpgsqlCommand(" select*from kisiileisbilgileri(@p1)", baglanti);
            komut5.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
            NpgsqlDataAdapter dsd = new NpgsqlDataAdapter(komut5);
            DataSet dsa = new DataSet();
            dsd.Fill(dsa);
            dataGridView2.DataSource = dsa.Tables[0];
            komut5.ExecuteNonQuery();
            baglanti.Close();
        }
    }
}
