﻿namespace vtys
{
    partial class kisi_ekle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.iletişimBilgileriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çalıştığıİşlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çalıştığıŞirketToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sosyalMedyaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.okulBilgileriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yetenekBecerilerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(33, 88);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(375, 221);
            this.dataGridView1.TabIndex = 36;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label1.Location = new System.Drawing.Point(175, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 41);
            this.label1.TabIndex = 37;
            this.label1.Text = "Kişi Bilgileri";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(525, 109);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 38;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(525, 166);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 39;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(525, 221);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 40;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label2.Location = new System.Drawing.Point(430, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 25);
            this.label2.TabIndex = 41;
            this.label2.Text = "İd";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.ImageKey = "(yok)";
            this.button1.Location = new System.Drawing.Point(670, 108);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 31);
            this.button1.TabIndex = 42;
            this.button1.Text = "Ekle";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(670, 161);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 31);
            this.button2.TabIndex = 43;
            this.button2.Text = "Güncelle";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(670, 216);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 31);
            this.button3.TabIndex = 44;
            this.button3.Text = "Sil";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(671, 279);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 30);
            this.button4.TabIndex = 45;
            this.button4.Text = "Listeleme";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label3.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label3.Location = new System.Drawing.Point(426, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 25);
            this.label3.TabIndex = 46;
            this.label3.Text = "Ad";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label4.Location = new System.Drawing.Point(426, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 25);
            this.label4.TabIndex = 47;
            this.label4.Text = "Soyad";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iletişimBilgileriToolStripMenuItem,
            this.çalıştığıİşlerToolStripMenuItem,
            this.çalıştığıŞirketToolStripMenuItem,
            this.sosyalMedyaToolStripMenuItem,
            this.aileToolStripMenuItem,
            this.okulBilgileriToolStripMenuItem,
            this.yetenekBecerilerToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 48;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // iletişimBilgileriToolStripMenuItem
            // 
            this.iletişimBilgileriToolStripMenuItem.Name = "iletişimBilgileriToolStripMenuItem";
            this.iletişimBilgileriToolStripMenuItem.Size = new System.Drawing.Size(99, 20);
            this.iletişimBilgileriToolStripMenuItem.Text = "İletişim Bilgileri";
            this.iletişimBilgileriToolStripMenuItem.Click += new System.EventHandler(this.iletişimBilgileriToolStripMenuItem_Click);
            // 
            // çalıştığıİşlerToolStripMenuItem
            // 
            this.çalıştığıİşlerToolStripMenuItem.Name = "çalıştığıİşlerToolStripMenuItem";
            this.çalıştığıİşlerToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.çalıştığıİşlerToolStripMenuItem.Text = "Çalıştığı İşler";
            this.çalıştığıİşlerToolStripMenuItem.Click += new System.EventHandler(this.çalıştığıİşlerToolStripMenuItem_Click);
            // 
            // çalıştığıŞirketToolStripMenuItem
            // 
            this.çalıştığıŞirketToolStripMenuItem.Name = "çalıştığıŞirketToolStripMenuItem";
            this.çalıştığıŞirketToolStripMenuItem.Size = new System.Drawing.Size(91, 20);
            this.çalıştığıŞirketToolStripMenuItem.Text = "çalıştığı Şirket";
            this.çalıştığıŞirketToolStripMenuItem.Click += new System.EventHandler(this.çalıştığıŞirketToolStripMenuItem_Click);
            // 
            // sosyalMedyaToolStripMenuItem
            // 
            this.sosyalMedyaToolStripMenuItem.Name = "sosyalMedyaToolStripMenuItem";
            this.sosyalMedyaToolStripMenuItem.Size = new System.Drawing.Size(91, 20);
            this.sosyalMedyaToolStripMenuItem.Text = "Sosyal Medya";
            this.sosyalMedyaToolStripMenuItem.Click += new System.EventHandler(this.sosyalMedyaToolStripMenuItem_Click);
            // 
            // aileToolStripMenuItem
            // 
            this.aileToolStripMenuItem.Name = "aileToolStripMenuItem";
            this.aileToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.aileToolStripMenuItem.Text = "Aile Bilgileri";
            this.aileToolStripMenuItem.Click += new System.EventHandler(this.aileToolStripMenuItem_Click);
            // 
            // okulBilgileriToolStripMenuItem
            // 
            this.okulBilgileriToolStripMenuItem.Name = "okulBilgileriToolStripMenuItem";
            this.okulBilgileriToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
            this.okulBilgileriToolStripMenuItem.Text = "Okul Bilgileri";
            this.okulBilgileriToolStripMenuItem.Click += new System.EventHandler(this.okulBilgileriToolStripMenuItem_Click);
            // 
            // yetenekBecerilerToolStripMenuItem
            // 
            this.yetenekBecerilerToolStripMenuItem.Name = "yetenekBecerilerToolStripMenuItem";
            this.yetenekBecerilerToolStripMenuItem.Size = new System.Drawing.Size(110, 20);
            this.yetenekBecerilerToolStripMenuItem.Text = "Yetenek/Beceriler";
            this.yetenekBecerilerToolStripMenuItem.Click += new System.EventHandler(this.yetenekBecerilerToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // kisi_ekle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "kisi_ekle";
            this.Text = "kisi_ekle";
            this.Load += new System.EventHandler(this.kisi_ekle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem iletişimBilgileriToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem çalıştığıİşlerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çalıştığıŞirketToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sosyalMedyaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem okulBilgileriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yetenekBecerilerToolStripMenuItem;
    }
}