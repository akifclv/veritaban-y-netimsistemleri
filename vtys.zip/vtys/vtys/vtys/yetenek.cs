﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vtys
{
    public partial class yetenek : Form
    {
        public yetenek()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection(" server=localHost; port=5432; Database=postgress ; user ID=postgres ; password=1234");

        private void sosyalBecerilerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sosyal s=new sosyal();
            s.Show();
        }

        private void sporBecerileriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            spor ş=new spor();
            ş.Show();
        }

        private void yabanciDilBecerileriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            yabanci y = new yabanci();
            y.Show();
        }

        private void güçlüYonleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            yonler ye=new yonler();
            ye.Show();
        }

        private void yetenek_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from kisiadmin";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];



            string sorgu1 = "select * from kisiyetenek";
            NpgsqlDataAdapter da1 = new NpgsqlDataAdapter(sorgu1, baglanti);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            dataGridView2.DataSource = ds1.Tables[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into kisiyetenek(yetenek_id) values(@p1)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("ekleme basarili");
        }
    }
}
