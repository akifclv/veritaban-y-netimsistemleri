﻿namespace vtys
{
    partial class yetenek
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.sosyalBecerilerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sporBecerileriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yabanciDilBecerileriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.güçlüYonleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(300, 388);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 30);
            this.button4.TabIndex = 57;
            this.button4.Text = "Listeleme";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label2.Location = new System.Drawing.Point(277, 324);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 25);
            this.label2.TabIndex = 53;
            this.label2.Text = "Yetenek İd";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(423, 329);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 50;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label1.Location = new System.Drawing.Point(136, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 51);
            this.label1.TabIndex = 49;
            this.label1.Text = "Kişi Bilgileri";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 102);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(375, 163);
            this.dataGridView1.TabIndex = 48;
            // 
            // button1
            // 
            this.button1.ImageKey = "(yok)";
            this.button1.Location = new System.Drawing.Point(423, 388);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 31);
            this.button1.TabIndex = 54;
            this.button1.Text = "Ekle";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sosyalBecerilerToolStripMenuItem,
            this.sporBecerileriToolStripMenuItem,
            this.yabanciDilBecerileriToolStripMenuItem,
            this.güçlüYonleriToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 58;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // sosyalBecerilerToolStripMenuItem
            // 
            this.sosyalBecerilerToolStripMenuItem.Name = "sosyalBecerilerToolStripMenuItem";
            this.sosyalBecerilerToolStripMenuItem.Size = new System.Drawing.Size(100, 20);
            this.sosyalBecerilerToolStripMenuItem.Text = "Sosyal Beceriler";
            this.sosyalBecerilerToolStripMenuItem.Click += new System.EventHandler(this.sosyalBecerilerToolStripMenuItem_Click);
            // 
            // sporBecerileriToolStripMenuItem
            // 
            this.sporBecerileriToolStripMenuItem.Name = "sporBecerileriToolStripMenuItem";
            this.sporBecerileriToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.sporBecerileriToolStripMenuItem.Text = "Spor Becerileri";
            this.sporBecerileriToolStripMenuItem.Click += new System.EventHandler(this.sporBecerileriToolStripMenuItem_Click);
            // 
            // yabanciDilBecerileriToolStripMenuItem
            // 
            this.yabanciDilBecerileriToolStripMenuItem.Name = "yabanciDilBecerileriToolStripMenuItem";
            this.yabanciDilBecerileriToolStripMenuItem.Size = new System.Drawing.Size(128, 20);
            this.yabanciDilBecerileriToolStripMenuItem.Text = "Yabanci Dil Becerileri";
            this.yabanciDilBecerileriToolStripMenuItem.Click += new System.EventHandler(this.yabanciDilBecerileriToolStripMenuItem_Click);
            // 
            // güçlüYonleriToolStripMenuItem
            // 
            this.güçlüYonleriToolStripMenuItem.Name = "güçlüYonleriToolStripMenuItem";
            this.güçlüYonleriToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.güçlüYonleriToolStripMenuItem.Text = "Güçlü Yönleri";
            this.güçlüYonleriToolStripMenuItem.Click += new System.EventHandler(this.güçlüYonleriToolStripMenuItem_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(423, 102);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(377, 163);
            this.dataGridView2.TabIndex = 59;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label3.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label3.Location = new System.Drawing.Point(526, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 51);
            this.label3.TabIndex = 60;
            this.label3.Text = "İd Numarası";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // yetenek
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "yetenek";
            this.Text = "yetenek";
            this.Load += new System.EventHandler(this.yetenek_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sosyalBecerilerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sporBecerileriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yabanciDilBecerileriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem güçlüYonleriToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label3;
    }
}