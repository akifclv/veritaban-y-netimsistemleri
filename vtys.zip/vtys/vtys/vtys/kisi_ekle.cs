﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vtys
{
    public partial class kisi_ekle : Form
    {
        NpgsqlConnection baglanti = new NpgsqlConnection(" server=localHost; port=5432; Database=postgress ; user ID=postgres ; password=1234");
        public kisi_ekle()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into kisiadmin(kisiadmin_id,kisiadmin_ad,kisiadmin_soyad) values(@p1,@p2,@p3)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
            komut1.Parameters.AddWithValue("@p2", textBox2.Text);
            komut1.Parameters.AddWithValue("@p3", textBox3.Text);
            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("ekleme basarili");
        }

        private void button2_Click(object sender, EventArgs e)
        {

            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("Update kisiadmin set kisiadmin_ad=@p2,kisiadmin_soyad=@p3 where kisiadmin_id=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
            komut3.Parameters.AddWithValue("@p2", textBox2.Text);
            komut3.Parameters.AddWithValue("@p3", textBox3.Text);
            komut3.ExecuteNonQuery();
            MessageBox.Show(" güncelleme basarili");
            baglanti.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut2 = new NpgsqlCommand("Delete from kisiadmin where kisiadmin_id=@p1", baglanti);
            komut2.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
            komut2.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("silme basarili");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from kisiadmin";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void iletişimBilgileriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            iletisim i = new iletisim();
            i.Show();
        }

        private void çalıştığıİşlerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            çalıştığı_isler ç = new çalıştığı_isler();
            ç.Show();
        }

        private void çalıştığıŞirketToolStripMenuItem_Click(object sender, EventArgs e)
        {
            calistigi_sirket c = new calistigi_sirket();
            c.Show();
        }

        private void sosyalMedyaToolStripMenuItem_Click(object sender, EventArgs e)
        {
           social_media s=new social_media();
            s.Show();
        }

        private void aileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            aile a=new aile();
            a.Show();
        }

        private void okulBilgileriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            okul o=new okul();
            o.Show();
        }

        private void yetenekBecerilerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            yetenek y = new yetenek();
            y.Show();
            
        }

        private void kisi_ekle_Load(object sender, EventArgs e)
        {

        }
    }
}
